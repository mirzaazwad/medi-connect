package com.example.MediConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
